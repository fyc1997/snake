package org.snake;

import java.awt.Color;
import java.awt.Graphics;

public class Cell {
	private int x,y;
	public Cell(){}
	public Cell(int x, int y) {
		super();
		this.x = x;
		this.y = y;
	}
	public Cell(Cell cell){
		this(cell.x,cell.y);
	}
	public int getX() {
		return x;
	}
	public void setX(int x) {
		this.x = x;
	}
	public int getY() {
		return y;
	}
	public void setY(int y) {
		this.y = y;
	}
	public void paint(Graphics g, Color b, Color f) {
		g.setColor(b);
		g.fillRect(x * WormStage.CELL_SIZE, y * WormStage.CELL_SIZE,
		WormStage.CELL_SIZE, WormStage.CELL_SIZE);
		g.setColor(f);
		g.drawRect(x * WormStage.CELL_SIZE, y * WormStage.CELL_SIZE,
		WormStage.CELL_SIZE, WormStage.CELL_SIZE);
	}
	@Override
	public String toString() {
		return "x=" + x + ", y=" + y ;
	}
}
